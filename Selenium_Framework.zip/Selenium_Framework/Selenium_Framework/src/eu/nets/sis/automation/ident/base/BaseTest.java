package eu.nets.sis.automation.ident.base;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import eu.nets.sis.properties.ApplicationProperties;
import eu.nets.sis.utils.ActionUtil;
import eu.nets.sis.utils.UtilityMethods;

public class BaseTest {

	public ActionUtil action = null;
	public UtilityMethods utilityMethods;
	public WebDriver driver = null;
	public String suiteName = null;
	
	@Parameters({ "suiteName" })
	@BeforeSuite(alwaysRun = true)
	public void suiteSetUp(@Optional("suiteName") String suiteName) throws Exception {
		this.suiteName=suiteName;
		deletePreviousTestOutputDirectory(this.suiteName);
		
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		utilityMethods = new UtilityMethods();
		driver = utilityMethods.launchBrowser();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		action = new ActionUtil(driver);
		
	}
	
	@AfterMethod
	public void afterMethod(ITestResult testResult) throws IOException {

		if (testResult.getStatus() == ITestResult.FAILURE) {
			Reporter.log("....Failed on below screen");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
			String path = null;
			if (ApplicationProperties.osname.startsWith("windows")) {
				path = ApplicationProperties.SHARE_PATH_LOCAL + File.separator +suiteName+ File.separator +timeStamp + "_testScreenShot.jpg";

			} else if (ApplicationProperties.osname.startsWith("linux")) {
				path = ApplicationProperties.SHARE_PATH_UNIX + File.separator +suiteName+ File.separator +timeStamp + "_testScreenShot.jpg";

			}
			File f1 = new File(path);

			FileUtils.copyFile(scrFile, f1);

			String filePath = f1.getAbsolutePath().toString();

			String paths = "<img src=\"file://" + filePath + "\" alt=\"\"/>";
			Reporter.setCurrentTestResult(testResult);
			Reporter.log(paths);

		}

		driver.quit();

	}

	public void takesSreenshot(WebDriver driver) throws IOException {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
		String path = null;
		if (ApplicationProperties.osname.startsWith("windows")) {
			path = ApplicationProperties.SHARE_PATH_LOCAL + File.separator+suiteName +File.separator + timeStamp + "_testScreenShot.jpg";

		} else if (ApplicationProperties.osname.startsWith("linux")) {
			path = ApplicationProperties.SHARE_PATH_UNIX + File.separator +suiteName+File.separator + timeStamp + "_testScreenShot.jpg";

		}
		File f1 = new File(path);

		FileUtils.copyFile(scrFile, f1);

		String filePath = f1.getAbsolutePath().toString();

		String paths = "<img src=\"file://" + filePath + "\" alt=\"\"/>";

		Reporter.log("\n"+paths);
	}

	public void deletePreviousTestOutputDirectory(String suiteName) {

		String path = null;
		if (ApplicationProperties.osname.startsWith("windows")) {
			path = ApplicationProperties.SHARE_PATH_LOCAL+File.separator+suiteName;

		} else if (ApplicationProperties.osname.startsWith("linux")) {
			path = ApplicationProperties.SHARE_PATH_UNIX+File.separator+suiteName;

		}
		File dir = new File(path);

		System.out.println("removing file or directory : " + dir.getAbsoluteFile());

		deleteDirectory(dir);

	}

	public static boolean deleteDirectory(File dir) {
		if (dir.isDirectory()) {
			File[] children = dir.listFiles();
			for (int i = 0; i < children.length; i++) {
				boolean success = deleteDirectory(children[i]);
				if (!success) {
					return false;
				}
			}
		}

		System.out.println("removing file or directory : " + dir.getName());
		return dir.delete();

	}

}
