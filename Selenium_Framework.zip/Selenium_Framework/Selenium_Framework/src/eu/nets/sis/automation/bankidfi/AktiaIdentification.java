package eu.nets.sis.automation.bankidfi;

import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import eu.nets.sis.automation.ident.base.BaseTest;
import eu.nets.sis.constatns.OidcClaimsConstants;
import eu.nets.sis.constatns.SamlAssertionDataConstants;
import eu.nets.sis.constatns.TestDataConstants;
import eu.nets.sis.finder.Selectors;
import eu.nets.sis.properties.ApplicationProperties;



public class AktiaIdentification extends BaseTest {

	@Test(description = "BanKIDFI Ident Aktia SAML ", priority = 1)
	public void banKIDFIIdentCompleteIdentificationSAML() throws Exception {
		Reporter.log("Begin BanKIDFI Ident Aktia Complete Identification SAML\n");
		driver.get(ApplicationProperties.testMerchant);
		Reporter.log("Selected BankIDFI(Tupas) check box\n");
		takesSreenshot(driver);
		action.click(Selectors.tupasCheckBox);
		action.click(Selectors.startAuth);
		driver.switchTo().frame(0);
		Reporter.log("Choose aktia from bank selection page\n");
		takesSreenshot(driver);
		action.click(Selectors.aktia);

		action.waitForElementVisibility(Selectors.aktiaUserID, 10);
		action.click(Selectors.aktiaUserID);
		action.clearTextField(Selectors.aktiaUserID);
		action.typeIn(Selectors.aktiaUserID, TestDataConstants.AKTIA_USERID);

		action.waitForElementVisibility(Selectors.aktiaPswd, 10);
		action.click(Selectors.aktiaPswd);
		action.clearTextField(Selectors.aktiaPswd);
		action.typeIn(Selectors.aktiaPswd, TestDataConstants.AKTIA_PWD);

		Reporter.log("Enter aktia  bank crdentials\n");
		takesSreenshot(driver);

		action.click(Selectors.aktiaSubmit);

		Reporter.log("Enter aktia  bank OTP\n");

		action.waitForElementVisibility(Selectors.aktiaOtp, 10);
		action.click(Selectors.aktiaOtp);
		action.clearTextField(Selectors.aktiaOtp);
		action.typeIn(Selectors.aktiaOtp, TestDataConstants.AKTIA_OTP);
		takesSreenshot(driver);

		action.click(Selectors.aktiaOtpContinue);

		action.waitForElementVisibility(Selectors.aktiaAllow, 10);
		action.click(Selectors.aktiaAllow);

		takesSreenshot(driver);
		Reporter.log("Submitted the aktia Identification\n");
		String status = action.waitForElementVisibility(Selectors.assertionText, 10).getText();
	
		Reporter.log("Verify assertion data\n");
		takesSreenshot(driver);
	
		assertTrue(status.contains(SamlAssertionDataConstants.AKTIA_STATUS_CODE),"Error in aktia status code");
		
		Assert.assertEquals(utilityMethods.assertDataSplit(status),SamlAssertionDataConstants.AKTIA_ASSERTION_DATA,"Error in aktia Assertion data");

		Reporter.log("End BanKIDFI Ident Aktia Complete Identification SAML\n");
		

	}
	

}