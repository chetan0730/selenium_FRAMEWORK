package eu.nets.sis.finder;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Selectors {
	
	WebDriver driver;

	// ident
	public static By bankIdCheckBox = By.cssSelector("#fno_nobankid");
	
}
