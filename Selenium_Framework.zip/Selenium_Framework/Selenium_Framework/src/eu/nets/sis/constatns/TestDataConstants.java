package eu.nets.sis.constatns;

public interface TestDataConstants {

	//oidc Reauthentication
	public String MAX_AGE = "70000";
	
	

}
