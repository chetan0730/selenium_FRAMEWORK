package eu.nets.sis.utils;

import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import eu.nets.sis.properties.ApplicationProperties;

public class UtilityMethods {

	/*
	 * initiate and Launch browser based on OS. Returns Driver isntance
	 */

	public WebDriver launchBrowser() {

		WebDriver driver = null;
		try {
			if (ApplicationProperties.osname.startsWith("windows") && ApplicationProperties.headlessRun==false) {

				System.setProperty("webdriver.chrome.driver", "resources/chromedriver.exe");

				driver = new ChromeDriver();

				driver.manage().window().maximize();

			} else if (ApplicationProperties.osname.startsWith("linux")  ) {
				{
					System.setProperty("webdriver.chrome.driver", "/opt/jenkins/automation/chromedriver");
					ChromeOptions chromeOptions = new ChromeOptions();
					chromeOptions.addArguments("headless");
					driver = new ChromeDriver(chromeOptions);
					driver.manage().window().maximize();
				}

			}
			else if (ApplicationProperties.osname.startsWith("windows") && ApplicationProperties.headlessRun==true ) {
				{
					System.setProperty("webdriver.chrome.driver", "resources/chromedriver.exe");
					ChromeOptions chromeOptions = new ChromeOptions();
					chromeOptions.addArguments("headless");
					driver = new ChromeDriver(chromeOptions);					
					driver.manage().window().maximize();
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return driver;

	}
	
	
	public  String assertDataSplit(String status)
	{
		ArrayList<String> assertiondata =new ArrayList<String>(Arrays.asList(status.split("<AttributeStatement>")));
		return assertiondata.get(1).trim();
	}

}
