package eu.nets.sis.utils;

import static org.testng.Assert.assertTrue;

import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ActionUtil {

	private WebDriver driver;
	public static String CURRENT_SCREEN_SHOT_PATH = "";
	public static String CURRENT_SCREEN_SHOT_LINK_PATH = "";
	static Logger log = Logger.getLogger(ActionUtil.class.getName());

	/**
	 * Constructor that takes the instantiation of driver and library
	 * 
	 * @param driver
	 * @param library
	 */
	public ActionUtil(WebDriver driver) {
		this.driver = driver;
	}

	

	/**
	 * Description : Does the Right Click on the element passed
	 * 
	 * @param By The element to perform the Right Click on
	 */
	public void rightClick(By byEle) {
		WebElement element = driver.findElement(byEle);
		try {
			Actions actions = new Actions(driver);
			actions.contextClick(element).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
		} catch (Exception e) {
			log.info(e.getMessage());
		}
	}

	/**
	 * Description : Does the click OR (wait & click) operation directly on the
	 * {@link WebElement} using elem.click();
	 * 
	 * @param ByEle   Element object
	 * @param waitFor The max timeout to wait and click(Pass 0 to do a direct click
	 *                without waiting) in seconds
	 */
	public void click(By byEle, Integer waitFor) {
		try {
			if (waitFor <= 0)
				driver.findElement(byEle).click();
			else if (waitFor > 0)
				waitForElementToBeClickable(byEle, waitFor).click();
		} catch (Exception e) {
			log.info(e.getMessage());
		}
	}
	
	
	/**
	 * Description : Does the wait(10 sec) & click operation directly on the
	 * {@link WebElement} using elem.click();
	 * 
	 * @param ByEle   Element object
	 * 
	 */
	public void click(By byEle) {
		try {
			
				waitForElementToBeClickable(byEle, 10).click();
		} catch (Exception e) {
			log.info(e.getMessage());
		}
	}

	/**
	 * Description : Gets the element and types in characters in the elements -
	 * Example: Text field
	 *
	 * @param ByEle      Element Object
	 * @param characters The character combination that could be keyed in by the
	 *                   user in the elements
	 */
	public void typeIn(By byEle, String characters) {
		try {
			Thread.sleep(2000);
			waitForElementVisibility(byEle, 10).sendKeys(characters);
		} catch (Exception e) {
			log.info(e.getMessage());

		}
	}

	public WebElement waitForElementVisibility(By byEle, Integer timeOut) {
		WebElement element = null;

		try {
			Thread.sleep(2000);

			element = new WebDriverWait(driver, timeOut.longValue())
					.until(ExpectedConditions.visibilityOfElementLocated(byEle));
			String original_style = element.getAttribute("style");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].style.border='3px solid red'", element);
			Thread.sleep(500);
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2])", element, "style", original_style);

		} catch (Exception e) {
			log.info(e.getMessage());
			assertTrue(false,byEle+"Element not found"); 
		}
		return element;

	}

	/**
	 * Description : Waits for the element to be clickable(ie.Enabled). Based on the
	 * {@link ISelector} type, it does the corresponding wait.
	 * 
	 * @param dict    The Dictionary Obj
	 * @param timeOut The max timeout to wait in seconds
	 * @return {@link WebElement} The element found after waiting
	 */
	public WebElement waitForElementToBeClickable(By byEle, Integer timeOut) {
		WebElement element = null;
		try {

			element = new WebDriverWait(driver, timeOut.longValue())
					.until(ExpectedConditions.elementToBeClickable(byEle));

		} catch (Exception e) {
			log.info(e.getMessage());
			assertTrue(false,byEle+"Element not found"); 
		}
		return element;
	}
	
	/**
	 * Description : Selects the drop down value based on the filter value provided
	 *
	 * @param dropDownSelector Selector of the respective drop down
	 * @param visibleFilter    Available values in the drop down
	 * @param filterValue      Filter value to select from the available values
	 * @return WebElement The respective value selected as an element
	 */
	public void selectDropDownValue(By dropDownSelector, String filterValue) {
		try {
			Select dropdown = new Select(driver.findElement(dropDownSelector));
			dropdown.selectByVisibleText(filterValue);
			Thread.sleep(4000);
		} catch (Exception e) {
			log.info(e.getMessage());
		}
	}

	/**
	 * Description : Checks if the element is visiblile
	 *
	 * @param byEle Element
	 * @return boolean
	 */

	public boolean isElementdisplayed(By byEle) {
		boolean dsiaplayed = false;
		try {
			dsiaplayed = driver.findElement(byEle).isDisplayed();
		} catch (Exception e) {
			log.info(e.getMessage());
		}
		return dsiaplayed;
	}

	public static boolean compareImage(String path1, String path2) {
		try {
			File file1 = new File(path1);
			File file2 = new File(path2);
			BufferedImage bufferedImage1 = ImageIO.read(file1);
			DataBuffer dataBuffer1 = bufferedImage1.getData().getDataBuffer();
			BufferedImage bufferedImage2 = ImageIO.read(file2);
			DataBuffer dataBuffer2 = bufferedImage2.getData().getDataBuffer();
			if (dataBuffer1.getSize() == dataBuffer2.getSize()) {
				for (int i = 0; i < dataBuffer1.getSize(); i++) {
					if (dataBuffer1.getElem(i) != dataBuffer2.getElem(i)) {
						return false;
					}
				}
				return true;
			}
		} catch (Exception e) {
			log.info("Failed to compare image files ... Path1: " + path1 + " Path2:" + path2);
		}
		return false;
	}
	/**
	 * Description : Clears the text in the text field if present
	 *
	 * @param byEle Element
	 * @return void
	 */

	public void clearTextField(By byEle) {
		boolean dsiaplayed = false;
		try {
			driver.findElement(byEle).clear();
		} catch (Exception e) {
			log.info(e.getMessage());
		}
		
	}
	/**
	 * Description : Varifys if particular text is present on page or not
	 *
	 * @param String
	 * @return Boolean
	 */
	public boolean isTextPresent(String text){
	    try{
	        boolean textPresent = driver.getPageSource().contains(text);
	        return textPresent;
	    }
	    catch(Exception e){
	        return false;
	    }
	  }
	
	
	
}


