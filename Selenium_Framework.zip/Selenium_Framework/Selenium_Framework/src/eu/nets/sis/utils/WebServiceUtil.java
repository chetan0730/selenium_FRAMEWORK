package eu.nets.sis.utils;

import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class WebServiceUtil {

	public String parseXMLwithNodeTagNames(String xmlRecords, String nodeTagName) {
		String tagValue = "";

		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = null;
			String s=new String(xmlRecords.getBytes(), "ISO-8859-1");
			doc = db.parse(new InputSource(new StringReader(s)));
			NodeList nl = doc.getElementsByTagName(nodeTagName);
			if (nl != null) {
				for (int i = 0; i < nl.getLength(); i++) {
					Node item = nl.item(i);
					NodeList name = item.getChildNodes();
					tagValue = item.getTextContent();

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tagValue;
	}

	public String parseXMLwithNodeTagNamesForAssertionData(String xmlRecords, String nodeTagName) {
		String tagValue = "";

		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = null;
			String s=new String(xmlRecords.getBytes(), "ISO-8859-1");
			doc = db.parse(new InputSource(new StringReader(s)));
			NodeList nl = doc.getElementsByTagName(nodeTagName);
//			if (nl != null) {
//				for (int i = 0; i < nl.getLength(); i++) {
//					Node item = nl.item(i);
//					NodeList name = item.getChildNodes();
//					tagValue = item.getTextContent();
//
//				}
//			}
			if (nl.getLength() > 0) {
			      System.out.println(nl.item(0));
			    }
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tagValue;
	}
	
	
	
	
	
	private String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
			CharacterData cd = (CharacterData) child;
			return cd.getData();
		}
		return "?";
	}
}
