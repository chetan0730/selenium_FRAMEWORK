package eu.nets.sis.utils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * The Class ExcelUtils is the utility class which has features related to excel
 * work. Few examples of excel related features are listed below.
 * 
 * 1. Get excel cell data from the excel sheet provided. 2. Get row count and
 * column count of the excel sheet. 3. Create the excel and write data into it.
 * 4. Append the data to excel file.
 * 
 */

public class ExcelUtil {
//
//
//	/** The log. */
//	static Logger log = Logger.getLogger(ExcelUtil.class.getName());
//
//	/** The path. */
//	public String path;
//
//	/** The fis. */
//	public FileInputStream fis = null;
//
//	/** The file out. */
//	public FileOutputStream fileOut = null;
//
//	/** The workbook. */
//	private Workbook workbook = null;
//
//	/** The sheet. */
//	private Sheet sheet = null;
//
//	/** The row. */
//	private Row row = null;
//
//	/** The cell. */
//	private Cell cell = null;
//
//	FileOutputStream fo;
//
//	BufferedInputStream inp;
//
//	// default constructor
//	/**
//	 * Instantiates a new excel utils.
//	 */
//	public ExcelUtil() {
//
//	}
//
//	/**
//	 * Description: It does initialize Excel Utils by passing excel path and
//	 * index of sheet to refer. Could be used for initializing both XSSF and
//	 * HSSF excel workbooks.
//	 *
//	 * @param excelPath
//	 *            The excel path location.
//	 * @param sheetIndex
//	 *            The sheet index of the excel sheet.
//	 */
//	public ExcelUtil(String excelPath, int sheetIndex) {
//		try {
//
//			inp = new BufferedInputStream(new FileInputStream(new File(excelPath).getAbsoluteFile()));
//
//			workbook = WorkbookFactory.create(inp);
//			if (workbook.getSheetAt(sheetIndex) != null) {
//				sheet = workbook.getSheetAt(sheetIndex);
//			}
//		} catch (Exception e) {
//			System.out.println(e);
//		}
//	}
//
//	/**
//	 * Description: It does initialize Excel Utils by passing excel path and
//	 * sheet name of sheet to refer. Could be used for initializing both XSSF
//	 * and HSSF excel workbooks.
//	 *
//	 * @param excelPath
//	 *            The excel path location.
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 */
//	public ExcelUtil(String excelPath, String sheetName) {
//		try {
//			InputStream inp = new FileInputStream(excelPath);
//			workbook = new XSSFWorkbook(inp);
//
//			if (isSheetExist(sheetName)) {
//				sheet = workbook.getSheet(sheetName);
//			} else {
//				log.info("Invalid Sheet Name. Sheet does not exist.");
//			}
//		} catch (Exception e) {
//			System.out.println(e);
//		}
//	}
//
//	/**
//	 * Description: It does initialize Excel Utils by passing inputStream and
//	 * sheet index of sheet to refer. Could be used for initializing both XSSF
//	 * and HSSF excel workbooks.
//	 *
//	 * @param inputStream
//	 *            The instance of InputStream to represent file for read/write
//	 *            operation.
//	 * @param sheetIndex
//	 *            The sheet index of the excel sheet.
//	 */
//	public ExcelUtil(InputStream inputStream, int sheetIndex) {
//		try {
//			workbook = WorkbookFactory.create(inputStream);
//
//			if (workbook.getSheetAt(sheetIndex) != null) {
//				sheet = workbook.getSheetAt(sheetIndex);
//			} else {
//				log.info("Invalid Sheet Index. Sheet does not exist.");
//			}
//		} catch (Exception e) {
//			System.out.println(e);
//		}
//	}
//
//	/**
//	 * The main method.
//	 *
//	 * @param args
//	 *            the arguments
//	 */
//	public static void main(String args[]) {
//		// call methods if required for internal testing purposes
//	}
//
//	/**
//	 * Description: It does print the contents of the excel sheet delimited by
//	 * '|' when sheet name is provided as input.
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 */
//	public void printSheetContents(String sheetName) {
//		if (isSheetExist(sheetName)) {
//			int rowCount = getRowCount(sheetName);
//			int columnCount = getColumnCount(sheetName);
//			log.info("Row count" + rowCount);
//			for (int i = 0; i < rowCount; i++) {
//				for (int j = 0; j < columnCount; j++) {
//					log.info(getCellData(sheetName, j, i) + " | ");
//				}
//			}
//		} else {
//			log.info("Invalid Sheet Name. Sheet does not exist.");
//		}
//	}
//
//	/**
//	 * Description: Returns the data from a cell if row number and column
//	 * numbers are passed along with sheet name.
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @param colNum
//	 *            The column number of the excel sheet.
//	 * @param rowNum
//	 *            The row number of the excel sheet.
//	 * @return String The cell data present in excel sheet cell.
//	 */
//	public String getCellData(String sheetName, int colNum, int rowNum) {
//		try {
//			if (rowNum <= 0)
//				return "";
//
//			int index = workbook.getSheetIndex(sheetName);
//
//			if (index == -1)
//				return "";
//
//			sheet = workbook.getSheetAt(index);
//			row = sheet.getRow(rowNum - 1);
//			if (row == null)
//				return "";
//			cell = row.getCell(colNum);
//			if (cell == null)
//				return "";
//			// Returns cell value based on its data type.
//			if (cell.getCellType() == Cell.CELL_TYPE_STRING)
//				return cell.getStringCellValue();
//			else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC || cell.getCellType() == Cell.CELL_TYPE_FORMULA) {
//				String cellText = String.valueOf(cell.getNumericCellValue());
//				return cellText;
//			} else if (cell.getCellType() == Cell.CELL_TYPE_BLANK)
//				return "";
//			else
//				return String.valueOf(cell.getBooleanCellValue());
//		} catch (Exception e) {
//			System.out.println(e);
//		}
//		return "";
//	}
//
//	/**
//	 * Description: Write a cell
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @param colNum
//	 *            The column number of the excel sheet.
//	 * @param rowNum
//	 *            The row number of the excel sheet. * @param excelPath The
//	 *            absolute path of the excel * @param rowNum The row number of
//	 *            the excel sheet.
//	 * @return String The cell data present in excel sheet cell.
//	 */
//	public String setCellData(String excelPath, String sheetName, int colNum, int rowNum, String value) {
//		try {
//
//			if (rowNum <= 0)
//				return "";
//
//			int index = workbook.getSheetIndex(sheetName);
//
//			if (index == -1)
//				return "";
//			sheet = workbook.getSheetAt(index);
//			Row row = sheet.getRow(rowNum - 1);
//			if (row == null)
//				return "";
//
//			Cell cel = row.createCell(colNum);
//			cel.setCellValue(value);
//
//			inp.close();
//
//			fo = new FileOutputStream(new File(excelPath).getAbsoluteFile());
//			workbook.write(fo);
//			fo.close();
//		} catch (Exception e) {
//			System.out.println(e);
//		}
//		return "";
//	}
//
//	/**
//	 * Description: Write Cell Headers Result Test URL Order ID Screenshot
//	 *
//	 * 
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @param colNum
//	 *            The column number of the excel sheet.
//	 * @param rowNum
//	 *            The row number of the excel sheet. * @param excelPath The
//	 *            absolute path of the excel * @param rowNum The row number of
//	 *            the excel sheet.
//	 * 
//	 */
//	public String setCellHeader(String excelPath, String sheetName, int colNum, int rowNum) {
//		try {
//
//			if (rowNum <= 0)
//				return "";
//
//			int index = workbook.getSheetIndex(sheetName);
//
//			if (index == -1)
//				return "";
//			sheet = workbook.getSheetAt(index);
//			Row row = sheet.getRow(rowNum - 1);
//			if (row == null)
//				return "";
//
//			Cell cel = row.createCell(colNum);
//			cel.setCellValue("Test Result");
//			cel = row.createCell(++colNum);
//			cel.setCellValue("Test URL");
//			cel = row.createCell(++colNum);
//			cel.setCellValue("OrderID");
//			cel = row.createCell(++colNum);
//			cel.setCellValue("Failiure Screenshots");
//
//			inp.close();
//
//			fo = new FileOutputStream(new File(excelPath).getAbsoluteFile());
//			workbook.write(fo);
//			fo.close();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return "";
//	}
//
//	/**
//	 * Description: Write a cell
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @param colNum
//	 *            The column number of the excel sheet.
//	 * @param rowNum
//	 *            The row number of the excel sheet. * @param excelPath The
//	 *            absolute path of the excel * @param rowNum The row number of
//	 *            the excel sheet.
//	 * @return String The cell data present in excel sheet cell.
//	 */
//	public String setCellDataWihHyperLink(String excelPath, String sheetName, int colNum, int rowNum, String value) {
//		try {
//
//			if (rowNum <= 0)
//				return "";
//
//			int index = workbook.getSheetIndex(sheetName);
//
//			if (index == -1)
//				return "";
//			sheet = workbook.getSheetAt(index);
//			Row row = sheet.getRow(rowNum - 1);
//			if (row == null)
//				return "";
//			CreationHelper createHelper = workbook.getCreationHelper();
//			CellStyle hlink_style = workbook.createCellStyle();
//			Font hlink_font = workbook.createFont();
//			hlink_font.setUnderline(Font.U_SINGLE);
//			hlink_font.setColor(IndexedColors.BLUE.getIndex());
//			hlink_style.setFont(hlink_font);
//			Hyperlink hp = createHelper.createHyperlink(Hyperlink.LINK_FILE);
//			Cell cel = row.createCell(colNum);
//			value = value.replace("\\", "/");
//			cel.setCellValue(value);
//
//			if (!value.equals("")) {
//				if (value.substring(0, 1).contains("/")) {
//					value = value.replaceAll(" ", "%20");
//				}
//			}
//			hp.setAddress(value);
//
//			// Cell cel=row.createCell(colNum);
//			cel.setHyperlink(hp);
//			// cel.setCellValue(value);
//			cel.setCellStyle(hlink_style);
//			inp.close();
//
//			fo = new FileOutputStream(new File(excelPath).getAbsoluteFile());
//			workbook.write(fo);
//			fo.close();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return "";
//	}
//
//	/**
//	 * Description: Checks if is sheet exist in the workbook, based on sheet
//	 * name passed as input.
//	 *
//	 * @param sheetName
//	 *            The sheet name passed as input to this method.
//	 * @return boolean It returns true if is sheet exist, otherwise it returns
//	 *         false.
//	 */
//	public boolean isSheetExist(String sheetName) {
//		int index = workbook.getSheetIndex(sheetName);
//		if (index == -1) {
//			index = workbook.getSheetIndex(sheetName.toUpperCase());
//			if (index == -1)
//				return false;
//			else
//				return true;
//		} else
//			return true;
//	}
//
//	/**
//	 * Description: It returns the work sheet when sheet name is passed as input
//	 * to this method.
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @return Sheet The work sheet is returned if sheet is found.
//	 */
//	public Sheet getWorkSheet(String sheetName) {
//		sheet = workbook.getSheet(sheetName);
//		return sheet;
//	}
//
//	/**
//	 * Description: It does return number of columns in a sheet of excel.
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @return int The column count is returned as output of this method.
//	 */
//	public int getColumnCount(String sheetName) {
//		// check if sheet exists
//		if (!isSheetExist(sheetName))
//			return -1;
//
//		sheet = workbook.getSheet(sheetName);
//		row = sheet.getRow(0);
//
//		if (row == null)
//			return -1;
//
//		return row.getLastCellNum();
//
//	}
//
//	/**
//	 * Description: It does return number of columns in a sheet excluding hidden
//	 * columns of excel.
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @return int The column count is returned as output of this method.
//	 */
//	public int getColumnCountExcludeHidden(String sheetName) {
//		// check if sheet exists
//		if (!isSheetExist(sheetName))
//			return -1;
//
//		sheet = workbook.getSheet(sheetName);
//		row = sheet.getRow(0);
//		if (row == null) {
//			return -1;
//		}
//		int columnCount = row.getLastCellNum();
//		Iterator<Cell> cellIterator = row.cellIterator();
//		while (cellIterator.hasNext()) {
//			Cell cell = cellIterator.next();
//			if (sheet.isColumnHidden(cell.getColumnIndex())) {
//				columnCount = columnCount - 1;
//			}
//		}
//		return columnCount;
//
//	}
//
//	/**
//	 * Description: It does return the row count in a sheet of excel sheet.
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet
//	 * @return int The number of rows are returned as output of this method.
//	 */
//	public int getRowCount(String sheetName) {
//		int index = workbook.getSheetIndex(sheetName);
//		if (index == -1)
//			return 0;
//		else {
//			sheet = workbook.getSheetAt(index);
//			int number = sheet.getLastRowNum() + 1;
//			return number;
//		}
//
//	}
//
//	/**
//	 * Description: It does return the list of header values present in a sheet
//	 * of excel sheet, when sheet name of that excel is provided as input.
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @return List<String> The header list present in a perticular sheet is
//	 *         returned as headerList.
//	 */
//	public List<String> getHeaderList(String sheetName) {
//		List<String> headerList = new ArrayList<String>();
//		int index = workbook.getSheetIndex(sheetName);
//		if (index != -1) {
//			sheet = workbook.getSheetAt(index);
//
//			Iterator<Row> rowIterator = sheet.iterator();
//			while (rowIterator.hasNext()) {
//				Row row = rowIterator.next();
//
//				// For each row, iterate through each columns
//				Iterator<Cell> cellIterator = row.cellIterator();
//				while (cellIterator.hasNext()) {
//					Cell cell = cellIterator.next();
//
//					switch (cell.getCellType()) {
//					case Cell.CELL_TYPE_BOOLEAN:
//						headerList.add(new Boolean(cell.getBooleanCellValue()).toString());
//						break;
//					case Cell.CELL_TYPE_NUMERIC:
//						headerList.add(new Double(cell.getNumericCellValue()).toString());
//						break;
//					case Cell.CELL_TYPE_STRING:
//						headerList.add(cell.getStringCellValue());
//						break;
//					}
//				}
//				break;
//			}
//
//		}
//		return headerList;
//	}
//
//	/**
//	 * Description: Return Header coulmn index in excel
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @return List<String> The header list present in a perticular sheet is
//	 *         returned as headerList.
//	 */
//	public int getHeaderColumnIndex(String sheetName, String headerColumn) {
//		List<String> headerList = new ArrayList<String>();
//		int indexC = 0;
//		int index = workbook.getSheetIndex(sheetName);
//		if (index != -1) {
//			sheet = workbook.getSheetAt(index);
//
//			Iterator<Row> rowIterator = sheet.iterator();
//			while (rowIterator.hasNext()) {
//				Row row = rowIterator.next();
//
//				// For each row, iterate through each columns
//				Iterator<Cell> cellIterator = row.cellIterator();
//				while (cellIterator.hasNext()) {
//					Cell cell = cellIterator.next();
//					if (cell.getStringCellValue().trim().contentEquals(headerColumn)) {
//						indexC = cell.getColumnIndex();
//						break;
//					}
//
//				}
//				break;
//			}
//
//		}
//		return indexC;
//	}
//
//	/**
//	 * Description: It does return the list of header values present in a sheet
//	 * of excel sheet, when sheet name of that excel is provided as input. It
//	 * excludes the hidden columns
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @return List<String> The header list present in a perticular sheet is
//	 *         returned as headerList.
//	 */
//	public List<String> getHeaderListExcludeHidden(String sheetName) {
//		List<String> headerList = new ArrayList<String>();
//		int index = workbook.getSheetIndex(sheetName);
//		if (index != -1) {
//			sheet = workbook.getSheetAt(index);
//
//			Iterator<Row> rowIterator = sheet.iterator();
//			while (rowIterator.hasNext()) {
//				Row row = rowIterator.next();
//
//				// For each row, iterate through each columns
//				Iterator<Cell> cellIterator = row.cellIterator();
//				while (cellIterator.hasNext()) {
//					Cell cell = cellIterator.next();
//					if (!sheet.isColumnHidden(cell.getColumnIndex())) {
//						switch (cell.getCellType()) {
//						case Cell.CELL_TYPE_BOOLEAN:
//							headerList.add(new Boolean(cell.getBooleanCellValue()).toString());
//							break;
//						case Cell.CELL_TYPE_NUMERIC:
//							headerList.add(new Double(cell.getNumericCellValue()).toString());
//							break;
//						case Cell.CELL_TYPE_STRING:
//							headerList.add(cell.getStringCellValue());
//							break;
//						}
//					}
//				}
//				break;
//			}
//
//		}
//		return headerList;
//	}
//
//	/**
//	 * Description: Returns list of sheet names in a excel workbook.
//	 *
//	 * @return List<String> The list of number of sheets in a excel workbook is
//	 *         returned as sheets.
//	 */
//	public List<String> getSheets() {
//		List<String> sheets = new ArrayList<String>();
//		for (int i = 0; i < workbook.getNumberOfSheets(); i++)
//			sheets.add(workbook.getSheetAt(i).getSheetName());
//		return sheets;
//	}
//
//	/**
//	 * Description: Returns name of sheet at specified index in a excel
//	 * workbook.
//	 *
//	 * @param index
//	 *            The index is the number passed to this method to find out
//	 *            sheet name.
//	 * @return String The sheet name is returned based on index passed.
//	 */
//	public String getSheetAt(int index) {
//		String sheetName = null;
//		try {
//			if (index < workbook.getNumberOfSheets())
//				sheetName = workbook.getSheetAt(index).getSheetName();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return sheetName;
//	}
//
//	/**
//	 * Description: This method iterates through each row and column in a
//	 * workbook sheet and returns the contents of the sheet in a table format.
//	 * Note: Mark skipHeader as true if the headers need not be added to the
//	 * output list.
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @param limit
//	 *            The limit as interger input.
//	 * @param skipHeader
//	 *            The boolean variable is passed to skip the headers in sheet.
//	 * @return List<List<String>> The row data is returned as entireData in list
//	 *         form.
//	 */
//	public List<List<String>> getRowData(String sheetName, int limit, boolean skipHeader) {
//		List<List<String>> entireData = new ArrayList<List<String>>();
//		int index = workbook.getSheetIndex(sheetName);
//		if (index != -1) {
//			sheet = workbook.getSheetAt(index);
//			Iterator<Row> rows = sheet.rowIterator();
//			List<String> rowData;
//			int cellCnt = 0;
//			while (rows.hasNext()) {
//				rowData = new ArrayList<String>();
//				Row row = rows.next();
//
//				if (row.getRowNum() == 0) {
//					cellCnt = row.getLastCellNum();
//					if (skipHeader && rows.hasNext())
//						row = rows.next();
//					row = rows.next();
//				}
//				for (int i = 0; i < cellCnt; i++) {
//					if (row != null) {
//						if (row.getCell(i) == null) {
//							rowData.add("");
//						} else {
//							rowData.add(getCellValue(row.getCell(i)));
//						}
//
//					}
//				}
//				entireData.add(rowData);
//				if (limit != 0 && row.getRowNum() >= limit)
//					break;
//			}
//
//		}
//		return entireData;
//	}
//
//	public List<List<String>> getRowDataWithFormatedNumericValue(int sheetIndex, boolean skipHeader, String pattern) {
//		DecimalFormat format = new DecimalFormat(pattern);
//		List<List<String>> entireRow = new ArrayList<List<String>>();
//		List<String> rowData;
//
//		XSSFCell cell;
//		String temp;
//
//		sheet = workbook.getSheetAt(sheetIndex);
//		FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
//		Iterator rows = sheet.rowIterator();
//
//		while (rows.hasNext()) {
//
//			row = (XSSFRow) rows.next();
//			Iterator cells = row.cellIterator();
//
//			rowData = new ArrayList<String>();
//			while (cells.hasNext()) {
//				cell = (XSSFCell) cells.next();
//
//				switch (evaluator.evaluateInCell(cell).getCellType()) {
//				case XSSFCell.CELL_TYPE_NUMERIC:
//					temp = format.format(Double.parseDouble(cell.getRawValue()));
//					rowData.add(temp);
//					break;
//				case XSSFCell.CELL_TYPE_STRING:
//					rowData.add(cell.getStringCellValue());
//					break;
//				}
//			}
//			entireRow.add(rowData);
//		}
//		return entireRow;
//	}
//
//	public List<List<String>> getRowDataAsString(String sheetName, int limit, boolean skipHeader) {
//		List<List<String>> entireData = new ArrayList<List<String>>();
//		int index = workbook.getSheetIndex(sheetName);
//		if (index != -1) {
//			sheet = workbook.getSheetAt(index);
//			Iterator<Row> rows = sheet.rowIterator();
//			List<String> rowData;
//			int cellCnt = 0;
//			while (rows.hasNext()) {
//				rowData = new ArrayList<String>();
//				Row row = rows.next();
//
//				if (row.getRowNum() == 0) {
//					cellCnt = row.getLastCellNum();
//					if (skipHeader && rows.hasNext())
//						row = rows.next();
//				}
//				for (int i = 0; i < cellCnt; i++) {
//					if (row != null) {
//						if (row.getCell(i) == null || row.getCell(i).getStringCellValue() == null) {
//							rowData.add("");
//						} else {
//							rowData.add((row.getCell(i).getStringCellValue().toString()));
//
//						}
//
//					}
//				}
//				entireData.add(rowData);
//				if (limit != 0 && row.getRowNum() >= limit)
//					break;
//			}
//
//		}
//		return entireData;
//	}
//
//	/**
//	 * Description: Gets the column data when sheet name and column position is
//	 * passed as input.
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @param skipHeader
//	 *            The skipheader is boolean passed as input.
//	 * @param columnPosition
//	 *            The column position in integer format is passed as input.
//	 * @return List<String> The column data is returned in list as columnData.
//	 */
//	public List<String> getColumnData(String sheetName, boolean skipHeader, int columnPosition) {
//		int limit = getRowCount(sheetName);
//		List<String> columnData = new ArrayList<String>();
//		int index = workbook.getSheetIndex(sheetName);
//		if (index != -1) {
//			sheet = workbook.getSheetAt(index);
//			Iterator<Row> rows = sheet.rowIterator();
//
//			while (rows.hasNext()) {
//
//				Row row = rows.next();
//
//				if (row.getRowNum() == 0) {
//
//					if (skipHeader && rows.hasNext())
//						row = rows.next();
//				}
//				{
//					if (row != null) {
//						if (row.getCell(columnPosition) == null) {
//							columnData.add("");
//						} else {
//							columnData.add(getCellValue(row.getCell(columnPosition)));
//						}
//
//					}
//				}
//
//				if (limit != 0 && row.getRowNum() >= limit)
//					break;
//			}
//
//		}
//		return columnData;
//	}
//
//	/**
//	 * Description: This method iterates through each row and column in a
//	 * workbook sheet and returns the contents of the sheet in a table format.
//	 * It skips the precision values and only counts digits before the decimal
//	 * point Note: Mark skipHeader as true if the headers need not be added to
//	 * the output list.
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @param limit
//	 *            The limit is passed as integer.
//	 * @param skipHeader
//	 *            The skipheader is passed as boolean input to this method.
//	 * @return List<List<String>> The row data is returned with no precision for
//	 *         digits entireData.
//	 */
//	public List<List<String>> getRowDataNoPrecision(String sheetName, int limit, boolean skipHeader) {
//		List<List<String>> entireData = new ArrayList<List<String>>();
//		int index = workbook.getSheetIndex(sheetName);
//		if (index != -1) {
//			sheet = workbook.getSheetAt(index);
//			Iterator<Row> rows = sheet.rowIterator();
//			List<String> rowData;
//			int cellCnt = 0;
//			while (rows.hasNext()) {
//				rowData = new ArrayList<String>();
//				Row row = rows.next();
//
//				if (row.getRowNum() == 0) {
//					cellCnt = row.getLastCellNum();
//					if (skipHeader && rows.hasNext())
//						row = rows.next();
//				}
//				for (int i = 0; i < cellCnt; i++) {
//					if (row != null) {
//						if (row.getCell(i) == null) {
//							rowData.add("");
//						} else {
//							String rowDataString = getCellValue(row.getCell(i));
//							if (rowDataString.contains(".")) {
//								rowDataString = rowDataString.substring(0, rowDataString.indexOf("."));
//							}
//							rowData.add(rowDataString);
//						}
//
//					}
//				}
//				entireData.add(rowData);
//				if (limit != 0 && row.getRowNum() >= limit)
//					break;
//			}
//
//		}
//		return entireData;
//	}
//
//	/**
//	 * Description: This method iterates through each row and column in a
//	 * workbook sheet and returns the contents of the sheet in a table format.
//	 * Note: Mark skipHeader as true if the headers need not be added to the
//	 * output list.
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @param limit
//	 *            The limit is integer input to this method.
//	 * @param skipHeader
//	 *            The skipheader boolean input to this method to include the
//	 *            header od not.
//	 * @return List<List<String>> The row data present in excel sheet name
//	 *         passed is returned as list.
//	 */
//
//	public List<List<String>> getRowDataNew(String sheetName, int limit, boolean skipHeader) {
//		List<List<String>> entireData = new ArrayList<List<String>>();
//		int index = workbook.getSheetIndex(sheetName);
//		if (index != -1) {
//			sheet = workbook.getSheetAt(index);
//			Iterator<Row> rows = sheet.rowIterator();
//			List<String> rowData;
//			int cellCnt = 0;
//			while (rows.hasNext()) {
//				rowData = new ArrayList<String>();
//				Row row = rows.next();
//				cellCnt = row.getLastCellNum();
//				if (row.getRowNum() == 0) {
//
//					if (skipHeader && rows.hasNext())
//						row = rows.next();
//				}
//				for (int i = 0; i < cellCnt; i++) {
//					if (row != null) {
//						if (row.getCell(i) == null) {
//							rowData.add("");
//						} else {
//							rowData.add(getCellValue(row.getCell(i)));
//						}
//
//					}
//				}
//				entireData.add(rowData);
//				if (limit != 0 && row.getRowNum() >= limit)
//					break;
//			}
//
//		}
//		return entireData;
//	}
//
//	/**
//	 * If passed an excel cell, this method will return the value of the cell in
//	 * string format based on type of cell provided as input.
//	 *
//	 * @param cell
//	 *            The poi api Cell instance passed as input to this method.
//	 * @return String The cell value returned in string format.
//	 */
//	public static String getCellValue(Cell cell) {
//		if (cell == null) {
//			return " ";
//		}
//		String val = "";
//		BigDecimal dec = BigDecimal.ZERO;
//		if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
//			if (null != cell.getStringCellValue())
//				return cell.getStringCellValue().trim();
//			else
//				return "";
//		} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
//			val = cell.getNumericCellValue() + "";
//			try {
//				DataFormatter fmt = new DataFormatter();
//				// if the value contains $, formatting it
//				if (val.contains("$")) {
//					if (fmt.formatCellValue(cell) != null && fmt.formatCellValue(cell).contains("$")) {
//						val = fmt.formatCellValue(cell);
//						return val;
//					}
//				}
//			} catch (Exception e) {
//				System.out.println(e);
//			}
//
//			// if the value contains 'E' or 'e', round it to ROUND_HALF_EVEN
//			if (val.contains("E") || val.contains("e")) {
//				dec = new BigDecimal(val);
//				BigDecimal roundoff = dec.setScale(2, BigDecimal.ROUND_HALF_EVEN);
//				val = "" + roundoff;
//				if (val.endsWith(".00")) {
//					return val.replace(".00", "");
//				} else if (val.endsWith(".0")) {
//					return val.replace(".0", "");
//				}
//				return "" + roundoff;
//			} else if (val.endsWith(".0")) {
//				return val.replace(".0", "");
//			} else {
//				return val;
//			}
//		} else if (cell.getCellType() == Cell.CELL_TYPE_BOOLEAN) {
//			return cell.getBooleanCellValue() + "";
//		} else if (cell.getCellType() == Cell.CELL_TYPE_BLANK) {
//			return cell.getStringCellValue().trim();
//		} else if (cell.getCellType() == Cell.CELL_TYPE_ERROR) {
//			return cell.getErrorCellValue() + "";
//		} else {
//			return null;
//		}
//	}
//
//	/**
//	 * Description: This method returns contents of the sheet in a table format.
//	 * The values are returned in respective data types.
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @param limit
//	 *            The limit passed as integer to this method.
//	 * @return List<List<Object>> The row data as object is returned.
//	 */
//	public List<List<Object>> getRowDataAsObject(String sheetName, int limit) {
//		List<List<Object>> entireData = new ArrayList<List<Object>>();
//		int index = workbook.getSheetIndex(sheetName);
//		if (index != -1) {
//			sheet = workbook.getSheetAt(index);
//			Iterator<Row> rows = sheet.rowIterator();
//			List<Object> rowData;
//			while (rows.hasNext()) {
//				rowData = new ArrayList<Object>();
//				Row row = rows.next();
//				if (row.getRowNum() == 0)
//					row = rows.next();
//				for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
//					// if (row != null && row.getCell(i) != null) {
//					if (row.getCell(i) != null) {
//						if (row.getCell(i).getCellType() == Cell.CELL_TYPE_STRING) {
//							if (null == row.getCell(i).getStringCellValue()) {
//								rowData.add(new String(""));
//							} else {
//								rowData.add(new String(row.getCell(i).getStringCellValue().trim()));
//							}
//						} else if (row.getCell(i).getCellType() == Cell.CELL_TYPE_NUMERIC
//								|| row.getCell(i).getCellType() == Cell.CELL_TYPE_FORMULA) {
//							System.out.println("excel " + row.getCell(i).getNumericCellValue());
//							rowData.add(new Double(row.getCell(i).getNumericCellValue()));
//						} else if (cell.getCellType() == Cell.CELL_TYPE_BLANK)
//							rowData.add(new String(""));
//						else {
//							rowData.add(new Boolean(row.getCell(i).getBooleanCellValue()));
//						}
//					}
//					// }
//				}
//				entireData.add(rowData);
//				if (limit != 0 && row.getRowNum() >= limit)
//					break;
//			}
//
//		}
//		return entireData;
//	}
//
//	/**
//	 * Description: This method writes given data to excel and supports only
//	 * .xlsx file format because of XSSFWorkbook.
//	 *
//	 * @param fileToDownload
//	 *            The file to read.
//	 * @param fileToUpload
//	 *            The file to write data.
//	 * @param data
//	 *            The data to write into file.
//	 * @return boolean It returns true if the data is written successfully into
//	 *         file, otherwise it will return false.
//	 */
//	public boolean appendDataToExcel(File fileToDownload, String fileToUpload, List<String> data) {
//		boolean returnValue = false;
//		try {
//			FileInputStream file = new FileInputStream(fileToDownload);
//
//			Workbook workbook = new XSSFWorkbook(file);
//			XSSFSheet sheet = (XSSFSheet) workbook.getSheetAt(0);
//			Cell cell = null;
//
//			int rowcnt = 1;
//			int cellcnt = 0;
//			for (String e : data) {
//				// Update the value of cell
//				cell = sheet.getRow(rowcnt).getCell(cellcnt);
//				if (cell != null) {
//					cell.setCellValue(e);
//				}
//				cellcnt = cellcnt + 1;
//			}
//			file.close();
//
//			FileOutputStream outFile = new FileOutputStream(new File(fileToUpload));
//			workbook.write(outFile);
//			outFile.close();
//			returnValue = true;
//
//		} catch (IOException e) {
//			System.out.println(e);
//		}
//		return returnValue;
//	}
//
//	/**
//	 * Description: This method writes given data to excel and Supports both
//	 * .xls and .xlsx file formats. The file may/may not contain headers based
//	 * on boolean value provided as input.
//	 *
//	 * @param inputFile
//	 *            The input excel file as input to thid method.
//	 * @param outputFileName
//	 *            The output file name to which the data is to be written.
//	 * @param data
//	 *            The data in list to write into excel.
//	 * @param skipHeader
//	 *            The boolean value passed as true or false.
//	 * @return boolean It returns true if the data is written successfully into
//	 *         file, otherwise it will return false.
//	 */
//	public boolean appendData(File inputFile, String outputFileName, List<List<String>> data, boolean skipHeader) {
//		boolean returnValue = false;
//		try {
//			FileInputStream file = new FileInputStream(inputFile);
//			Workbook workbook = null;
//			Sheet sheet = null;
//
//			if (inputFile.getAbsolutePath().endsWith("XLSX")) {
//				workbook = new XSSFWorkbook(file);
//				sheet = (XSSFSheet) workbook.getSheetAt(0);
//			} else {
//				workbook = new HSSFWorkbook(file);
//				sheet = (HSSFSheet) workbook.getSheetAt(0);
//			}
//
//			Cell cell = null;
//
//			int excelRowIndex = 0;
//			if (skipHeader)
//				excelRowIndex = 1;
//			int dataRowIndex = 0;
//			for (List<String> rows : data) {
//				Row row;
//				if ((row = sheet.getRow(excelRowIndex)) == null)
//					row = sheet.createRow(excelRowIndex);
//				List<String> rowData = data.get(dataRowIndex);
//				for (int cellIndex = 0; cellIndex < rows.size(); cellIndex++) {
//					// Update the value of cell
//					if ((cell = row.getCell(cellIndex)) == null)
//						cell = row.createCell(cellIndex);
//					cell.setCellValue(rowData.get(cellIndex));
//				}
//				excelRowIndex++;
//				dataRowIndex++;
//			}
//			file.close();
//
//			FileOutputStream outFile = new FileOutputStream(new File(outputFileName).getAbsoluteFile());
//			workbook.write(outFile);
//			outFile.close();
//			returnValue = true;
//
//		} catch (Exception e) {
//			System.out.println(e);
//		}
//		return returnValue;
//	}
//
//	/**
//	 * Description: Deletes excel from given path.
//	 *
//	 * @param path
//	 *            The path as input to this method to delete the file from a
//	 *            path.
//	 */
//	public void deleteExcel(String path) {
//		try {
//
//			File file = new File(path);
//
//			if (file.delete()) {
//				log.info(file.getName() + " is deleted!");
//			} else {
//				log.info("Delete operation failed.");
//			}
//		} catch (Exception e) {
//			System.out.println(e);
//		}
//	}
//
//	/**
//	 * Description: Deletes all excel files from given path which has given
//	 * prefix and extension.
//	 *
//	 * @param directory
//	 *            The directory on file system.
//	 * @param prefix
//	 *            The prefix of the file
//	 * @param extension
//	 *            The extension of the file
//	 */
//	public void deleteExcel(String directory, final String prefix, final String extension) {
//		try {
//			if (null == directory) {
//				log.info("Delete operation failed..File does not exist");
//				throw new NullPointerException("File must not be null");
//			}
//			File dir = new File(directory);
//			File[] filesList = dir.listFiles(new FilenameFilter() {
//				// filtering the files by its extension
//				public boolean accept(File dir, String name) {
//					return name.startsWith(prefix) && name.toLowerCase().endsWith(extension);
//				}
//			});
//
//			if (filesList != null) {
//				for (File excel : filesList) {
//					if (excel.delete()) {
//						log.info(excel.getName() + " is deleted!");
//					} else {
//						log.info("Delete operation failed.");
//					}
//				}
//			}
//		} catch (Exception e) {
//			System.out.println(e);
//		}
//	}
//
//	/**
//	 * Description: Creates an excel and writes data to it based on file name
//	 * and data in list is passed to this method.
//	 *
//	 * @param outputFileName
//	 *            The output file name of excel.
//	 * @param data
//	 *            The data to be written into excel.
//	 * @return boolean It returns true if the data is written successfully into
//	 *         file, otherwise it will return false.
//	 */
//	public boolean createExcel(String outputFileName, List<List<String>> data) {
//		boolean returnValue = false;
//		try {
//			XSSFWorkbook workbook = new XSSFWorkbook();
//			XSSFSheet sheet = workbook.createSheet("Mismatched Rows");
//			int dataRowIndex = 0;
//			for (List<String> rows : data) {
//				XSSFRow row;
//				row = sheet.createRow(dataRowIndex);
//				List<String> rowData = data.get(dataRowIndex);
//				for (int cellIndex = 0; cellIndex < rows.size(); cellIndex++) {
//					// Update the value of cell
//					if ((cell = row.getCell(cellIndex)) == null)
//						cell = row.createCell(cellIndex);
//					cell.setCellValue(rowData.get(cellIndex));
//				}
//				dataRowIndex++;
//			}
//			FileOutputStream outFile = new FileOutputStream(new File(outputFileName));
//			workbook.write(outFile);
//			outFile.close();
//			returnValue = true;
//
//		} catch (IOException e) {
//			System.out.println(e);
//		}
//		return returnValue;
//	}
//
//	/**
//	 * Description: Creates an excel and writes data to it. The file path, file
//	 * name, list of data and header count is input to this method.
//	 *
//	 * @param outputFilePath
//	 *            The output file path of excel.
//	 * @param fileName
//	 *            The file name of the excel.
//	 * @param sheetName
//	 *            The sheet name within excel.
//	 * @param dataList
//	 *            The data list to be written into this excel file.
//	 * @param headerCount
//	 *            The header count in given excel sheet.
//	 * @return boolean It returns true if the data is written successfully into
//	 *         file, otherwise it will return false.
//	 */
//	public boolean createExcel(String outputFilePath, String fileName, String sheetName, List<List<String>> dataList,
//			int headerCount) {
//		boolean returnValue = false;
//		try {
//			XSSFWorkbook workbook = new XSSFWorkbook();
//			XSSFSheet sheet = workbook.createSheet(sheetName);
//			int dataRowIndex = 0;
//			for (List<String> rows : dataList) {
//				XSSFRow row;
//				row = sheet.createRow(dataRowIndex);
//				List<String> rowData = dataList.get(dataRowIndex);
//				for (int cellIndex = 0; cellIndex < rows.size(); cellIndex++) {
//					// Update the value of cell
//					if ((cell = row.getCell(cellIndex)) == null)
//						cell = row.createCell(cellIndex);
//					cell.setCellValue(rowData.get(cellIndex));
//				}
//				dataRowIndex++;
//			}
//			FileOutputStream outFile = new FileOutputStream(new File(outputFilePath + fileName));
//			sheet = workbook.getSheetAt(0);
//			/* Shrink to fit headers */
//			for (int i = 0; i < headerCount; i++) {
//				sheet.autoSizeColumn(i);
//			}
//
//			/* Make the headers bold */
//			makeRowBold(workbook, sheet.getRow(0));
//			workbook.write(outFile);
//			outFile.close();
//			returnValue = true;
//
//		} catch (IOException e) {
//			System.out.println(e);
//		}
//		return returnValue;
//
//	}
//
//	/**
//	 * Description: The method is used to make header row in bold.
//	 *
//	 * @param wb
//	 *            The workbook is passed as input to this method.
//	 * @param row
//	 *            The row whose cells need to make bold.
//	 */
//	public static void makeRowBold(Workbook wb, Row row) {
//		CellStyle style = wb.createCellStyle();// Create style
//		XSSFFont font = (XSSFFont) wb.createFont();// Create font
//		font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);// Make font bold
//		style.setFont(font);// set it to bold
//		style.setWrapText(true);
//
//		for (int i = 0; i < row.getLastCellNum(); i++) {// For each cell in the
//														// row
//			row.getCell(i).setCellStyle(style);// Set the style
//		}
//
//	}
//
//	/**
//	 * Description: The Results write into the column which specified in
//	 * columnIndex that starts from the row which specified in rowIndex
//	 *
//	 * @param columnsNameList
//	 *            Results should be in the form of List of String
//	 * @param xssfWorkbook
//	 *            Results to write into the workbook
//	 * @param sheetName
//	 *            Results to write into the specified sheet in the workbook
//	 * @param rowIndex
//	 *            Results starts to write from the specified row index
//	 * @param columnIndex
//	 *            Results starts to write in the specified column index
//	 * 
//	 */
//	public XSSFWorkbook resultIntoColumn(String value, XSSFWorkbook xssfWorkbook, String sheetName, int rowIndex,
//			int columnIndex, String path) {
//
//		Row xssfRow = null;
//		Cell xssfCell = null;
//		XSSFSheet sheet = xssfWorkbook.getSheet(sheetName);
//
//		if (sheet == null) {
//			sheet = xssfWorkbook.createSheet(sheetName);
//		}
//
//		xssfRow = sheet.createRow(rowIndex);
//
//		xssfCell = xssfRow.createCell(columnIndex);
//		xssfCell.setCellValue(value);
//
//		return xssfWorkbook;
//	}
//
//	/**
//	 * Description: The Results write into the column which specified in
//	 * columnIndex that starts from the row which specified in rowIndex
//	 *
//	 * @param columnsNameList
//	 *            Results should be in the form of List of String
//	 * @param xssfWorkbook
//	 *            Results to write into the workbook
//	 * @param sheetName
//	 *            Results to write into the specified sheet in the workbook
//	 * 
//	 */
//	public static XSSFWorkbook resultIntoWorkbook(List<Map<String, Object>> resultset, XSSFWorkbook workbook,
//			String sheetName) {
//		XSSFSheet sheet = null;
//		sheet = workbook.createSheet(sheetName);
//		Row row = null;
//		Cell cell = null;
//
//		int rowIndex = 0;
//		int columnIndex = 0;
//		String header = "";
//		String rowValue = "";
//
//		if (resultset != null && resultset.size() > 0) {
//
//			// Writing Headers
//			row = sheet.createRow(rowIndex++);
//			columnIndex = 0;
//
//			for (Map.Entry<String, Object> entry : resultset.get(0).entrySet()) {
//				cell = row.createCell(columnIndex++);
//				header = entry.getKey();
//				cell.setCellValue(header);
//			}
//
//			// Writing Results
//			for (Map<String, Object> map : resultset) {
//				row = sheet.createRow(rowIndex++);
//				columnIndex = 0;
//				for (Map.Entry<String, Object> entry : map.entrySet()) {
//
//					cell = row.createCell(columnIndex++);
//					if (entry.getValue() != null) {
//						rowValue = entry.getValue().toString();
//					} else {
//						rowValue = "";
//					}
//					cell.setCellValue(rowValue);
//				}
//			}
//		}
//
//		return workbook;
//	}
//
//	/**
//	 * Description: This method iterates through each row and column in a
//	 * workbook sheet and returns the contents of the sheet in a table format.It
//	 * will format the cell value in the form of comma and scale value. Note:
//	 * Mark skipHeader as true if the headers need not be added to the output
//	 * list.
//	 *
//	 * @param sheetName
//	 *            The sheet name of the excel sheet.
//	 * @param limit
//	 *            Number of rows.
//	 * @param skipHeader
//	 *            The boolean variable is passed to skip the headers in sheet.
//	 * @param scaleValue
//	 *            ScaleValue for the rational numbers
//	 * @param rationalColNos
//	 *            Rational column number indexes. Index will start from 0
//	 * @param integerColNos
//	 *            Rational column number indexes. Index will start from 0
//	 * @return List<List<String>> The row data is returned as entireData in list
//	 *         form.
//	 */
//	public List<List<String>> getFormatedRowDataWithScaleAndCommaForm(String sheetName, int limit, boolean skipHeader,
//			int scaleValue, List<Integer> rationalColNos, List<Integer> integerColNos, boolean commaReqFlag) {
//		String scaleValues = "";
//		for (int i = 0; i < scaleValue; i++) {
//			scaleValues = scaleValues + "0";
//		}
//		String numberFormat = "####";
//		if (commaReqFlag) {
//			numberFormat = "#,###";
//		}
//		List<List<String>> formatedData = new ArrayList<List<String>>();
//		int index = workbook.getSheetIndex(sheetName);
//		if (index != -1) {
//			sheet = workbook.getSheetAt(index);
//			Iterator<Row> rows = sheet.rowIterator();
//			List<String> rowData;
//			int cellCnt = 0;
//			while (rows.hasNext()) {
//				rowData = new ArrayList<String>();
//				Row row = rows.next();
//				if (row.getRowNum() == 0) {
//					cellCnt = row.getLastCellNum();
//					if (skipHeader && rows.hasNext())
//						row = rows.next();
//				}
//				for (int i = 0; i < cellCnt; i++) {
//					if (row != null) {
//						if (row.getCell(i) == null) {
//							rowData.add("");
//						} else {
//							rowData.add(getFormatedCellValue(row.getCell(i), rationalColNos, integerColNos,
//									commaReqFlag, scaleValues, numberFormat));
//						}
//					}
//				}
//				formatedData.add(rowData);
//				if (limit != 0 && row.getRowNum() >= limit)
//					break;
//			}
//		}
//		return formatedData;
//	}
//
//	/**
//	 * Description: It will format the cell value in the form of comma and scale
//	 * value.
//	 * 
//	 * @param cell
//	 *            Cell object
//	 * @param rationalColNos
//	 *            Rational column number indexes. Index will start from 0
//	 * @param integerColNos
//	 *            Rational column number indexes. Index will start from 0
//	 * @param scaleValues
//	 *            ScaleValues format.Eq: If number is 123.20 then scaleValues
//	 *            will be 00.
//	 * @param numberFormat
//	 *            Number format for values.like #,###
//	 * @return List<List<String>> The row data is returned as entireData in list
//	 *         form.
//	 */
//	public static String getFormatedCellValue(Cell cell, List<Integer> rationalColNos, List<Integer> integerColNos,
//			boolean commaReqFlag, String scaleValues, String numberFormat) {
//		try {
//			if (cell == null) {
//				return " ";
//			}
//			String val = "";
//			BigDecimal dec = BigDecimal.ZERO;
//			if ((rationalColNos == null && integerColNos == null)
//					|| (rationalColNos != null && !rationalColNos.contains(cell.getColumnIndex())
//							&& integerColNos != null && !integerColNos.contains(cell.getColumnIndex()))
//					|| (rationalColNos == null && integerColNos != null
//							&& !integerColNos.contains(cell.getColumnIndex()))
//					|| (integerColNos == null && rationalColNos != null
//							&& !rationalColNos.contains(cell.getColumnIndex()))) {
//				if (cell.getCellType() != Cell.CELL_TYPE_STRING) {
//					cell.setCellType(Cell.CELL_TYPE_STRING);
//				}
//			}
//			if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
//				if (null != cell.getStringCellValue())
//					return cell.getStringCellValue().trim();
//				else
//					return "";
//			} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
//				val = cell.getNumericCellValue() + "";
//				try {
//					DataFormatter fmt = new DataFormatter();
//					// if the value contains $, formatting it
//					if (val.contains("$")) {
//						if (fmt.formatCellValue(cell) != null && fmt.formatCellValue(cell).contains("$")) {
//							val = fmt.formatCellValue(cell);
//							return val;
//						}
//					}
//				} catch (Exception e) {
//					System.out.println(e);
//				}
//				// if the value contains 'E' or 'e', round it to ROUND_HALF_EVEN
//				if (val.contains("E") || val.contains("e")) {
//					if ((scaleValues != null && !scaleValues.equals("")) || commaReqFlag) {
//						val = getFormatedValue(val, numberFormat, scaleValues, rationalColNos, integerColNos,
//								cell.getColumnIndex());
//					} else {
//						dec = new BigDecimal(val);
//						BigDecimal roundoff = dec.setScale(2, BigDecimal.ROUND_HALF_EVEN);
//						val = "" + roundoff;
//						if (val.endsWith(".00")) {
//							return val.replace(".00", "");
//						} else if (val.endsWith(".0")) {
//							return val.replace(".0", "");
//						}
//						val = "" + roundoff;
//						;
//					}
//					return val;
//				} else if ((scaleValues != null && !scaleValues.equals("")) || commaReqFlag) {
//					if ((val.equals("0.0") || val.equals("0")) && rationalColNos != null
//							&& rationalColNos.contains(cell.getColumnIndex())) {
//						double amount = Double.parseDouble(val);
//						DecimalFormat formatter = new DecimalFormat(numberFormat + "." + scaleValues);
//						val = formatter.format(amount);
//						val = "0" + val;
//					} else {
//						val = getFormatedValue(val, numberFormat, scaleValues, rationalColNos, integerColNos,
//								cell.getColumnIndex());
//					}
//					return val;
//				} else {
//					return val;
//				}
//			} else if (cell.getCellType() == Cell.CELL_TYPE_BOOLEAN) {
//				return cell.getBooleanCellValue() + "";
//			} else if (cell.getCellType() == Cell.CELL_TYPE_BLANK) {
//				return cell.getStringCellValue().trim();
//			} else if (cell.getCellType() == Cell.CELL_TYPE_ERROR) {
//				return cell.getErrorCellValue() + "";
//			} else {
//				return null;
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return null;
//	}
//
//	private static String getFormatedValue(String val, String numberFormat, String scaleValues,
//			List<Integer> rationalColNos, List<Integer> integerColNos, int colNo) {
//		if (val.contains(".") && rationalColNos != null && rationalColNos.contains(colNo)) {
//			double amount = Double.parseDouble(val);
//			DecimalFormat formatter = new DecimalFormat(numberFormat + "." + scaleValues);
//			val = formatter.format(amount);
//			if (val.startsWith(".")) {
//				val = "0" + val;
//			} else if (val.startsWith("-.")) {
//				val = val.replace("-", "-0");
//			}
//		} else if (integerColNos != null && integerColNos.contains(colNo)) {
//			if (val.contains(".")) {
//				String[] values = val.split("\\.");
//				if (values != null && values[0] != null) {
//					val = values[0];
//				}
//			}
//			long amount = Long.parseLong(val);
//			DecimalFormat formatter = new DecimalFormat(numberFormat);
//			val = formatter.format(amount);
//		}
//		return val;
//	}
//
//	/**
//	 * Description: Method returns the list of images present in the workbook.
//	 *
//	 * @return List The list of pictures in the workbook.
//	 */
//
//	public List getPictures() {
//
//		if (workbook != null) {
//			return workbook.getAllPictures();
//		} else {
//			return Collections.emptyList();
//		}
//	}
}