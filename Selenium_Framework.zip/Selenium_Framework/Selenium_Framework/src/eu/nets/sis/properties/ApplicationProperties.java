package eu.nets.sis.properties;

public interface ApplicationProperties {

	public String useHeadlessWindows = "nos"; // Default is firefox. Set "yes" for Phantom
	public String SHARE_PATH_UNIX = "target/surefire-reports";
	public String SHARE_PATH_LOCAL = "target/surefire-reports";
	String osname = System.getProperty("os.name", "").toLowerCase();
	Boolean headlessRun = false;
	public String testMerchant = "https://www-dev;

}
